import PanelProfesional from "./PanelProfesional.jsx";

export default function App() {
  return <PanelProfesional />;
}